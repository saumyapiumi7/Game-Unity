namespace Reference
{
    public interface IHitPlayer
    {
        public void OnHitPlayer();
    }
}
